document.querySelector('.contact-form').addEventListener('submit', function(e) {
    e.preventDefault();
    alert('پیام شما ارسال شد!');
});
